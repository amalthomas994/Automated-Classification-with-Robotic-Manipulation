% 
% L1=8;
% L2=9.5;
% L3=9.5;
% L4=0;
% L5=0;
% 
% D1=15;
% D2=0;
% D3=0;
% D4=-1;
% D5=4.5;
% 
% AL1=deg2rad(0);
% AL2=deg2rad(90);
% AL3=deg2rad(0);
% AL4=deg2rad(90);
% AL5=deg2rad(0);
% 
% angle1=input('angle1 = ');
% angle2=input('angle2 = ');
% angle3=input('angle3 = ');
% angle4=input('angle4 = ');
% angle5=input('angle5 = ');
% 
% TH1=deg2rad(angle1);
% TH2=deg2rad(angle2);
% TH3=deg2rad(angle3);
% TH4=deg2rad(angle4+90);
% TH5=deg2rad(angle5);
% 
% A1 = [  cos(TH1) -sin(TH1)*cos(AL1) sin(TH1)*sin(AL1) L1*cos(TH1); 
%         sin(TH1) cos(TH1)*cos(AL1) -cos(TH1)*sin(AL1) L1*sin(TH1);
%         0 sin(AL1) cos(AL1) D1;
%         0 0 0 1];
% 
% A2 = [cos(TH2) -sin(TH2)*cos(AL2) sin(TH2)*sin(AL2) L2*cos(TH2); 
%     sin(TH2) cos(TH2)*cos(AL2) -cos(TH2)*sin(AL2) L2*sin(TH2);
%     0 sin(AL2) cos(AL2) D2;
%     0 0 0 1];
% 
% 
% 
% A3 = [cos(TH3) -sin(TH3)*cos(AL3) sin(TH3)*sin(AL3) L3*cos(TH3); 
%     sin(TH3) cos(TH3)*cos(AL3) -cos(TH3)*sin(AL3) L3*sin(TH3);
%     0 sin(AL3) cos(AL3) D3;
%     0 0 0 1];
% 
% 
% A4 = [cos(TH4) -sin(TH4)*cos(AL4) sin(TH4)*sin(AL4) L4*cos(TH4); 
%     sin(TH4) cos(TH4)*cos(AL4) -cos(TH4)*sin(AL4) L4*sin(TH4);
%     0 sin(AL4) cos(AL4) D4;
%     0 0 0 1];
% 
% A5 = [cos(TH5) -sin(TH5)*cos(AL5) sin(TH5)*sin(AL5) L5*cos(TH5); 
%     sin(TH5) cos(TH5)*cos(AL5) -cos(TH5)*sin(AL5) L5*sin(TH5);
%     0 sin(AL5) cos(AL5) D5;
%     0 0 0 1];


x=9.5;
y=13;
    A1 = [-1, 0, 0,     x;
            0,  -1, 0,     y;
            0   ,  0 , 1,     0;
            0 ,  0          , 0,     1];
         
      
x2=5;
y2=13;
    A2 = [1, 0, 0,     x2;
            0,  1, 0,     y2;
            0          ,  0          , 1,     0;
            0          ,  0          , 0,     1];
        
        
A=A1*inv(A2);
%*A3*A4*A5;
a=A(1,1);
b=A(1,2);
c=A(1,3);
d=A(1,4);
e=A(2,1);
f=A(2,2);
g=A(2,3);
h=A(2,4);
i=A(3,1);
j=A(3,2);
k=A(3,3);
l=A(3,4);


d5=4.5;
l3=9.5;
d4=-1;
l2=9.5;
l1=8;
d1=15;


q41=0;
q42=0;
q43=0;
q44=1;


%theta equations
Tbout=asind(k);
 
% theta 5
if (-j>=0)
T5out=acosd((i)/cosd(Tbout));
 
else
T5out=asind((-j)/(cosd(Tbout)));
end
 
% theta 3
T3out=asind((((-d5)*(sind(Tbout))-(d1)+(l))/(l3)));
 
%theta 4
if (T3out>=0)
T4out=acosd(((i)/cosd(T5out)))-T3out;
else
T4out=Tbout-T3out;
end
 
% if (q24>=0)
% T1out=acosd((q14-(d5)*(cosd(acosd((q13)/cosd(Tbout))))*cosd(acosd((q31)/(cosd(T5out))))-(l3)*(cosd((acosd((q13)/(cosd(Tbout))))))*cosd(T3out)+(d4)*sind((asind((q23)/(cosd(Tbout)))))-(l2)*cosd((acosd((q13)/(cosd(Tbout))))))/(l1));
% else
% T1out=asind((q24-(d5)*(sind(asind((q23)/cosd(Tbout))))*cosd(acosd((q31)/(cosd(T5out))))-(l3)*(sind((asind((q23)/(cosd(Tbout))))))*cosd(T3out)-(d4)*cosd((acosd((q13)/(cosd(Tbout)))))-(l2)*sind((asind((q23)/(cosd(Tbout))))))/(l1));
% end
 T1out = asind((h-d5*sind(asind((g)/cosd(Tbout)))*cosd(Tbout)-l3*sind(asind((g)/cosd(Tbout)))*cosd(T3out)+d4*cosd((acosd((c)/(cosd(Tbout)))))-l2*sind(asind((g)/cosd(Tbout))))/l1);
% theta 2
if (g>=0)
 
    Taout=acosd((c)/cosd(Tbout));
     T2out=Taout-T1out;
 
else
  Taout=asind((g)/cosd(Tbout));
T2out=Taout-T1out;
 
end
 
disp(T1out);
disp(T2out);
disp(T3out);
disp(T4out);
disp(T5out);

