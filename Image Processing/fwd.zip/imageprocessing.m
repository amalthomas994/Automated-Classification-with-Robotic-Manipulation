image = imread('second1.bmp');
cropped = imcrop(image, [0 0 400 500]);
gray_image = rgb2gray(cropped);
imwrite(gray_image, 'gray_image.bmp');
medfilt_image = medfilt2(gray_image,[5,5]);
gray = im2bw(image, 0.3);
complement=imcomplement(gray);
complement2 = imcrop(complement, [0 0 640 480]);


center = regionprops(complement2, 'centroid');
centroids = cat(1, center.Centroid);
bound = regionprops(complement2, 'BoundingBox');
dis = regionprops(complement2, 'MajorAxisLength');

% for k = 1 : length(bound)
%   thisBB = bound(k).BoundingBox;
%   rectangle('Position', [thisBB(1),thisBB(2),thisBB(3),thisBB(4)],...
%   'EdgeColor','r','LineWidth',2 )
% end

imshow(complement2)
hold on
plot(centroids(:,1), centroids(:,2), 'b*')
% hold on
% plot(bound)
hold off
conversion = 3.6/56.153;

orientation = regionprops(complement2, 'Orientation');
area = regionprops(complement2, 'Area');
orien = [orientation.Orientation];
are = [area.Area];
cent = [center.Centroid];
corx = cent(1);
cory=cent(2);

corx = cent(3) - cent(1);
cory = cent(4) - cent(2);
corxx = corx*conversion
 coryy = cory*conversion
% aew = are(2);

corxx1 = int2str(corxx);
coryy1 = int2str(coryy);

move = 'move all to';
fid=fopen('robotcoordinates2.rbx','w');
fprintf(fid, [ move ' ' corxx1 '\n']);
% fprintf(fid, [''])
% fprintf(fid, center);
fclose(fid);
aree2 = int64(are(2));


if ((1350<aree2) && (aree2<1800))
    disp('rectangle')

elseif ((800<aree2)&&(aree2<1000))
    disp('circle')
    
elseif ((550<aree2)&&(aree2<600))
    disp('triangle')

else ((1100<aree2)&&(aree2<1400))
    disp('square')
end

